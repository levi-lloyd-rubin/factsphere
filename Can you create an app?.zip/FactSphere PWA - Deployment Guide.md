# FactSphere PWA - Deployment Guide

## Quick Deploy Options

### Option 1: GitHub Pages (Free & Permanent)
1. Create a new GitHub repository
2. Upload all files to the repository
3. Go to Settings → Pages
4. Select "Deploy from a branch" → main branch
5. Your app will be live at: `https://yourusername.github.io/repository-name`

### Option 2: Netlify (Free & Easy)
1. Go to netlify.com
2. Drag and drop this folder to deploy
3. Get instant permanent URL

### Option 3: Vercel (Free & Fast)
1. Go to vercel.com
2. Import from GitHub or upload files
3. Get instant permanent URL

### Option 4: Any Web Hosting
Upload all files to any web hosting service's public folder.

## Files Included
- `index.html` - Main PWA application
- `manifest.json` - Web app manifest
- `sw.js` - Service worker for offline functionality
- `icon-*.png` - App icons for different devices

## Features
- ✅ Progressive Web App (PWA)
- ✅ Installable on mobile devices
- ✅ Offline functionality
- ✅ Random facts generator
- ✅ Responsive design
- ✅ Custom app icons

## Installation for Users
Once deployed, users can install the app:
- **Android Chrome:** Menu → "Add to Home screen"
- **iOS Safari:** Share → "Add to Home Screen"
- **Desktop:** Install icon in address bar

